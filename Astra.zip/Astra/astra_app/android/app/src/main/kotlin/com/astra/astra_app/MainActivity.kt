package com.astra.astra_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
