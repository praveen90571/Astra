class AppConfig {
  // Environment
  static const bool isDevelopment = true;
  static const bool enableLogging = true;
  
  // Firebase Configuration (you'll add your config here)
  static const String firebaseWebApiKey = 'your-web-api-key';
  static const String firebaseAndroidAppId = 'your-android-app-id';
  static const String firebaseIosAppId = 'your-ios-app-id';
  static const String firebaseProjectId = 'astra-motorcycle-app';
  
  // Google Maps API Key (you'll need to get this)
  static const String googleMapsApiKey = 'your-google-maps-api-key';
  
  // Socket.IO Configuration (for future backend)
  static const String socketUrl = isDevelopment 
      ? 'http://localhost:3000' 
      : 'https://your-production-url.com';
  
  // Feature Flags
  static const bool enableRealTimeTracking = true;
  static const bool enableEmergencyAlerts = true;
  static const bool enableVoiceNavigation = false; // Future feature
  
  // App Settings
  static const Duration sessionTimeout = Duration(hours: 8);
  static const Duration locationUpdateInterval = Duration(seconds: 5);
  static const int maxRetryAttempts = 3;
}