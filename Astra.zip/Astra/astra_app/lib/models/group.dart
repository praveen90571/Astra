import 'location.dart';
import 'user.dart';

enum GroupStatus {
  planning,    // Group created, planning route
  active,      // Currently riding
  paused,      // Stopped/break
  completed,   // Ride finished
  cancelled,   // Ride cancelled
}

enum MemberRole {
  leader,      // Can set destinations, approve stops
  member,      // Can suggest stops, send alerts
}

class GroupMember {
  final String userId;
  final String name;
  final MemberRole role;
  final DateTime joinedAt;
  final bool isOnline;
  final RiderLocation? currentLocation;
  final DateTime? lastLocationUpdate;

  GroupMember({
    required this.userId,
    required this.name,
    required this.role,
    required this.joinedAt,
    this.isOnline = false,
    this.currentLocation,
    this.lastLocationUpdate,
  });

  factory GroupMember.fromMap(Map<String, dynamic> map) {
    return GroupMember(
      userId: map['userId'],
      name: map['name'],
      role: MemberRole.values.firstWhere(
        (role) => role.name == map['role'],
        orElse: () => MemberRole.member,
      ),
      joinedAt: DateTime.parse(map['joinedAt']),
      isOnline: map['isOnline'] ?? false,
      currentLocation: map['currentLocation'] != null
          ? RiderLocation.fromMap(map['currentLocation'])
          : null,
      lastLocationUpdate: map['lastLocationUpdate'] != null
          ? DateTime.parse(map['lastLocationUpdate'])
          : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'name': name,
      'role': role.name,
      'joinedAt': joinedAt.toIso8601String(),
      'isOnline': isOnline,
      'currentLocation': currentLocation?.toMap(),
      'lastLocationUpdate': lastLocationUpdate?.toIso8601String(),
    };
  }

  // Check if member's location is recent
  bool get hasRecentLocation {
    if (lastLocationUpdate == null) return false;
    return DateTime.now().difference(lastLocationUpdate!).inMinutes < 2;
  }

  GroupMember copyWith({
    String? name,
    MemberRole? role,
    bool? isOnline,
    RiderLocation? currentLocation,
    DateTime? lastLocationUpdate,
  }) {
    return GroupMember(
      userId: userId,
      name: name ?? this.name,
      role: role ?? this.role,
      joinedAt: joinedAt,
      isOnline: isOnline ?? this.isOnline,
      currentLocation: currentLocation ?? this.currentLocation,
      lastLocationUpdate: lastLocationUpdate ?? this.lastLocationUpdate,
    );
  }
}

class Group {
  final String id;
  final String name;
  final String description;
  final String leaderId;
  final List<GroupMember> members;
  final GroupStatus status;
  final RiderLocation? destination;
  final List<RiderLocation> suggestedStops;
  final List<RiderLocation> approvedStops;
  final DateTime createdAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final String joinCode;
  final Map<String, dynamic>? rideStats; // Distance, duration, etc.

  Group({
    required this.id,
    required this.name,
    required this.description,
    required this.leaderId,
    required this.members,
    required this.status,
    this.destination,
    this.suggestedStops = const [],
    this.approvedStops = const [],
    required this.createdAt,
    this.startedAt,
    this.completedAt,
    required this.joinCode,
    this.rideStats,
  });

  factory Group.fromMap(Map<String, dynamic> map, String id) {
    return Group(
      id: id,
      name: map['name'],
      description: map['description'] ?? '',
      leaderId: map['leaderId'],
      members: (map['members'] as List?)
          ?.map((member) => GroupMember.fromMap(member))
          .toList() ?? [],
      status: GroupStatus.values.firstWhere(
        (status) => status.name == map['status'],
        orElse: () => GroupStatus.planning,
      ),
      destination: map['destination'] != null
          ? RiderLocation.fromMap(map['destination'])
          : null,
      suggestedStops: (map['suggestedStops'] as List?)
          ?.map((stop) => RiderLocation.fromMap(stop))
          .toList() ?? [],
      approvedStops: (map['approvedStops'] as List?)
          ?.map((stop) => RiderLocation.fromMap(stop))
          .toList() ?? [],
      createdAt: DateTime.parse(map['createdAt']),
      startedAt: map['startedAt'] != null 
          ? DateTime.parse(map['startedAt']) 
          : null,
      completedAt: map['completedAt'] != null 
          ? DateTime.parse(map['completedAt']) 
          : null,
      joinCode: map['joinCode'],
      rideStats: map['rideStats'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'description': description,
      'leaderId': leaderId,
      'members': members.map((member) => member.toMap()).toList(),
      'status': status.name,
      'destination': destination?.toMap(),
      'suggestedStops': suggestedStops.map((stop) => stop.toMap()).toList(),
      'approvedStops': approvedStops.map((stop) => stop.toMap()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'startedAt': startedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'joinCode': joinCode,
      'rideStats': rideStats,
    };
  }

  // Helper methods
  bool get isActive => status == GroupStatus.active;
  bool get isPaused => status == GroupStatus.paused;
  bool get isCompleted => status == GroupStatus.completed;
  bool get isPlanning => status == GroupStatus.planning;
  
  int get memberCount => members.length;
  List<GroupMember> get onlineMembers => members.where((m) => m.isOnline).toList();
  List<GroupMember> get membersWithRecentLocation => members.where((m) => m.hasRecentLocation).toList();
  
  GroupMember? get leader => members.firstWhere(
    (member) => member.role == MemberRole.leader,
    orElse: () => members.first,
  );

  bool isUserLeader(String userId) {
    return leaderId == userId || members.any((m) => m.userId == userId && m.role == MemberRole.leader);
  }

  bool isUserMember(String userId) {
    return members.any((m) => m.userId == userId);
  }

  Duration? get rideDuration {
    if (startedAt == null) return null;
    DateTime endTime = completedAt ?? DateTime.now();
    return endTime.difference(startedAt!);
  }

  Group copyWith({
    String? name,
    String? description,
    List<GroupMember>? members,
    GroupStatus? status,
    RiderLocation? destination,
    List<RiderLocation>? suggestedStops,
    List<RiderLocation>? approvedStops,
    DateTime? startedAt,
    DateTime? completedAt,
    Map<String, dynamic>? rideStats,
  }) {
    return Group(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      leaderId: leaderId,
      members: members ?? this.members,
      status: status ?? this.status,
      destination: destination ?? this.destination,
      suggestedStops: suggestedStops ?? this.suggestedStops,
      approvedStops: approvedStops ?? this.approvedStops,
      createdAt: createdAt,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
      joinCode: joinCode,
      rideStats: rideStats ?? this.rideStats,
    );
  }

  @override
  String toString() {
    return 'Group(id: $id, name: $name, members: ${members.length}, status: ${status.name})';
  }
}