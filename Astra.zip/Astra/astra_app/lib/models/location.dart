enum LocationType {
  rider,        // Current rider position
  destination,  // Final destination
  stop,         // Approved stop point
  suggested,    // Suggested stop
  emergency,    // Emergency location
}

enum EmergencyType {
  breakdown,    // Mechanical issue
  accident,     // Accident occurred
  medical,      // Medical emergency
  fuel,         // Out of fuel
  weather,      // Weather-related stop
}

class RiderLocation {
  final String id;
  final double latitude;
  final double longitude;
  final double? altitude;
  final double? accuracy;
  final double? speed;
  final double? heading;
  final DateTime timestamp;
  final String? address;
  final LocationType type;
  final String? description;
  final String? userId;
  final EmergencyType? emergencyType;
  final bool isActive;

  RiderLocation({
    required this.id,
    required this.latitude,
    required this.longitude,
    this.altitude,
    this.accuracy,
    this.speed,
    this.heading,
    required this.timestamp,
    this.address,
    required this.type,
    this.description,
    this.userId,
    this.emergencyType,
    this.isActive = true,
  });

  factory RiderLocation.fromMap(Map<String, dynamic> map) {
    return RiderLocation(
      id: map['id'] ?? '',
      latitude: map['latitude']?.toDouble() ?? 0.0,
      longitude: map['longitude']?.toDouble() ?? 0.0,
      altitude: map['altitude']?.toDouble(),
      accuracy: map['accuracy']?.toDouble(),
      speed: map['speed']?.toDouble(),
      heading: map['heading']?.toDouble(),
      timestamp: DateTime.parse(map['timestamp']),
      address: map['address'],
      type: LocationType.values.firstWhere(
        (type) => type.name == map['type'],
        orElse: () => LocationType.rider,
      ),
      description: map['description'],
      userId: map['userId'],
      emergencyType: map['emergencyType'] != null
          ? EmergencyType.values.firstWhere(
              (type) => type.name == map['emergencyType'],
            )
          : null,
      isActive: map['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'latitude': latitude,
      'longitude': longitude,
      'altitude': altitude,
      'accuracy': accuracy,
      'speed': speed,
      'heading': heading,
      'timestamp': timestamp.toIso8601String(),
      'address': address,
      'type': type.name,
      'description': description,
      'userId': userId,
      'emergencyType': emergencyType?.name,
      'isActive': isActive,
    };
  }

  // Calculate distance to another location in meters
  double distanceTo(RiderLocation other) {
    const double earthRadius = 6371000; // Earth's radius in meters
    
    double lat1Rad = latitude * (3.14159265359 / 180);
    double lat2Rad = other.latitude * (3.14159265359 / 180);
    double deltaLatRad = (other.latitude - latitude) * (3.14159265359 / 180);
    double deltaLngRad = (other.longitude - longitude) * (3.14159265359 / 180);

    double a = (deltaLatRad / 2) * (deltaLatRad / 2) +
        lat1Rad * lat2Rad *
        (deltaLngRad / 2) * (deltaLngRad / 2);
    
    double c = 2 * (a * (1 - a));
    
    return earthRadius * c;
  }

  // Check if location is recent (within last 30 seconds)
  bool get isRecent {
    return DateTime.now().difference(timestamp).inSeconds < 30;
  }

  // Check if this is an emergency location
  bool get isEmergency => type == LocationType.emergency;

  // Get formatted speed
  String get speedKmh {
    if (speed == null) return 'N/A';
    return '${(speed! * 3.6).toStringAsFixed(1)} km/h';
  }

  // Get formatted address or coordinates
  String get displayLocation {
    return address ?? '${latitude.toStringAsFixed(6)}, ${longitude.toStringAsFixed(6)}';
  }

  RiderLocation copyWith({
    String? id,
    double? latitude,
    double? longitude,
    double? altitude,
    double? accuracy,
    double? speed,
    double? heading,
    DateTime? timestamp,
    String? address,
    LocationType? type,
    String? description,
    String? userId,
    EmergencyType? emergencyType,
    bool? isActive,
  }) {
    return RiderLocation(
      id: id ?? this.id,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      altitude: altitude ?? this.altitude,
      accuracy: accuracy ?? this.accuracy,
      speed: speed ?? this.speed,
      heading: heading ?? this.heading,
      timestamp: timestamp ?? this.timestamp,
      address: address ?? this.address,
      type: type ?? this.type,
      description: description ?? this.description,
      userId: userId ?? this.userId,
      emergencyType: emergencyType ?? this.emergencyType,
      isActive: isActive ?? this.isActive,
    );
  }

  @override
  String toString() {
    return 'RiderLocation(id: $id, lat: $latitude, lng: $longitude, type: ${type.name})';
  }
}