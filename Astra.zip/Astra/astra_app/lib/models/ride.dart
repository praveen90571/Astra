import 'location.dart';
import 'group.dart';

enum RideType {
  casual,      // Casual group ride
  touring,     // Long distance touring
  commuting,   // Daily commute group
  adventure,   // Off-road adventure
  track,       // Track day
}

class RideWaypoint {
  final String id;
  final RiderLocation location;
  final String? name;
  final String? description;
  final DateTime? arrivalTime;
  final Duration? stopDuration;
  final bool isCompleted;

  RideWaypoint({
    required this.id,
    required this.location,
    this.name,
    this.description,
    this.arrivalTime,
    this.stopDuration,
    this.isCompleted = false,
  });

  factory RideWaypoint.fromMap(Map<String, dynamic> map) {
    return RideWaypoint(
      id: map['id'],
      location: RiderLocation.fromMap(map['location']),
      name: map['name'],
      description: map['description'],
      arrivalTime: map['arrivalTime'] != null 
          ? DateTime.parse(map['arrivalTime']) 
          : null,
      stopDuration: map['stopDuration'] != null 
          ? Duration(seconds: map['stopDuration']) 
          : null,
      isCompleted: map['isCompleted'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'location': location.toMap(),
      'name': name,
      'description': description,
      'arrivalTime': arrivalTime?.toIso8601String(),
      'stopDuration': stopDuration?.inSeconds,
      'isCompleted': isCompleted,
    };
  }
}

class RideStats {
  final double totalDistance; // in meters
  final Duration totalDuration;
  final Duration movingTime;
  final double averageSpeed; // in m/s
  final double maxSpeed; // in m/s
  final double totalElevationGain; // in meters
  final int numberOfStops;
  final List<RiderLocation> route;

  RideStats({
    required this.totalDistance,
    required this.totalDuration,
    required this.movingTime,
    required this.averageSpeed,
    required this.maxSpeed,
    required this.totalElevationGain,
    required this.numberOfStops,
    required this.route,
  });

  factory RideStats.fromMap(Map<String, dynamic> map) {
    return RideStats(
      totalDistance: map['totalDistance']?.toDouble() ?? 0.0,
      totalDuration: Duration(seconds: map['totalDuration'] ?? 0),
      movingTime: Duration(seconds: map['movingTime'] ?? 0),
      averageSpeed: map['averageSpeed']?.toDouble() ?? 0.0,
      maxSpeed: map['maxSpeed']?.toDouble() ?? 0.0,
      totalElevationGain: map['totalElevationGain']?.toDouble() ?? 0.0,
      numberOfStops: map['numberOfStops'] ?? 0,
      route: (map['route'] as List?)
          ?.map((location) => RiderLocation.fromMap(location))
          .toList() ?? [],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'totalDistance': totalDistance,
      'totalDuration': totalDuration.inSeconds,
      'movingTime': movingTime.inSeconds,
      'averageSpeed': averageSpeed,
      'maxSpeed': maxSpeed,
      'totalElevationGain': totalElevationGain,
      'numberOfStops': numberOfStops,
      'route': route.map((location) => location.toMap()).toList(),
    };
  }

  // Helper getters
  String get totalDistanceKm => '${(totalDistance / 1000).toStringAsFixed(1)} km';
  String get averageSpeedKmh => '${(averageSpeed * 3.6).toStringAsFixed(1)} km/h';
  String get maxSpeedKmh => '${(maxSpeed * 3.6).toStringAsFixed(1)} km/h';
  String get formattedDuration {
    int hours = totalDuration.inHours;
    int minutes = totalDuration.inMinutes.remainder(60);
    return hours > 0 ? '${hours}h ${minutes}m' : '${minutes}m';
  }
}

class Ride {
  final String id;
  final String groupId;
  final String name;
  final String? description;
  final RideType type;
  final RiderLocation startLocation;
  final RiderLocation? endLocation;
  final List<RideWaypoint> waypoints;
  final DateTime createdAt;
  final DateTime? startedAt;
  final DateTime? completedAt;
  final RideStats? stats;
  final Map<String, List<RiderLocation>> memberPaths; // userId -> path
  final List<String> emergencyAlerts;
  final bool isPublic;

  Ride({
    required this.id,
    required this.groupId,
    required this.name,
    this.description,
    required this.type,
    required this.startLocation,
    this.endLocation,
    this.waypoints = const [],
    required this.createdAt,
    this.startedAt,
    this.completedAt,
    this.stats,
    this.memberPaths = const {},
    this.emergencyAlerts = const [],
    this.isPublic = false,
  });

  factory Ride.fromMap(Map<String, dynamic> map, String id) {
    return Ride(
      id: id,
      groupId: map['groupId'],
      name: map['name'],
      description: map['description'],
      type: RideType.values.firstWhere(
        (type) => type.name == map['type'],
        orElse: () => RideType.casual,
      ),
      startLocation: RiderLocation.fromMap(map['startLocation']),
      endLocation: map['endLocation'] != null 
          ? RiderLocation.fromMap(map['endLocation']) 
          : null,
      waypoints: (map['waypoints'] as List?)
          ?.map((waypoint) => RideWaypoint.fromMap(waypoint))
          .toList() ?? [],
      createdAt: DateTime.parse(map['createdAt']),
      startedAt: map['startedAt'] != null 
          ? DateTime.parse(map['startedAt']) 
          : null,
      completedAt: map['completedAt'] != null 
          ? DateTime.parse(map['completedAt']) 
          : null,
      stats: map['stats'] != null 
          ? RideStats.fromMap(map['stats']) 
          : null,
      memberPaths: Map<String, List<RiderLocation>>.from(
        (map['memberPaths'] as Map?)?.map((key, value) => 
          MapEntry(key, (value as List).map((location) => 
            RiderLocation.fromMap(location)).toList())) ?? {}),
      emergencyAlerts: List<String>.from(map['emergencyAlerts'] ?? []),
      isPublic: map['isPublic'] ?? false,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'groupId': groupId,
      'name': name,
      'description': description,
      'type': type.name,
      'startLocation': startLocation.toMap(),
      'endLocation': endLocation?.toMap(),
      'waypoints': waypoints.map((waypoint) => waypoint.toMap()).toList(),
      'createdAt': createdAt.toIso8601String(),
      'startedAt': startedAt?.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'stats': stats?.toMap(),
      'memberPaths': memberPaths.map((key, value) => 
        MapEntry(key, value.map((location) => location.toMap()).toList())),
      'emergencyAlerts': emergencyAlerts,
      'isPublic': isPublic,
    };
  }

  // Helper methods
  bool get isActive => startedAt != null && completedAt == null;
  bool get isCompleted => completedAt != null;
  bool get hasEmergencies => emergencyAlerts.isNotEmpty;
  
  Duration? get duration {
    if (startedAt == null) return null;
    DateTime endTime = completedAt ?? DateTime.now();
    return endTime.difference(startedAt!);
  }

  @override
  String toString() {
    return 'Ride(id: $id, name: $name, type: ${type.name}, isActive: $isActive)';
  }
}