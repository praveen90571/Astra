class User {
  final String id;
  final String name;
  final String email;
  final String? phoneNumber;
  final String? profileImageUrl;
  final String? fcmToken; // For push notifications
  final DateTime createdAt;
  final DateTime lastSeen;
  final bool isOnline;
  final RiderLocation? lastKnownLocation;

  User({
    required this.id,
    required this.name,
    required this.email,
    this.phoneNumber,
    this.profileImageUrl,
    this.fcmToken,
    required this.createdAt,
    required this.lastSeen,
    this.isOnline = false,
    this.lastKnownLocation,
  });

  // Convert from Firebase document
  factory User.fromMap(Map<String, dynamic> map, String id) {
    return User(
      id: id,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phoneNumber: map['phoneNumber'],
      profileImageUrl: map['profileImageUrl'],
      fcmToken: map['fcmToken'],
      createdAt: DateTime.parse(map['createdAt']),
      lastSeen: DateTime.parse(map['lastSeen']),
      isOnline: map['isOnline'] ?? false,
      lastKnownLocation: map['lastKnownLocation'] != null
          ? RiderLocation.fromMap(map['lastKnownLocation'])
          : null,
    );
  }

  // Convert to Firebase document
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phoneNumber': phoneNumber,
      'profileImageUrl': profileImageUrl,
      'fcmToken': fcmToken,
      'createdAt': createdAt.toIso8601String(),
      'lastSeen': lastSeen.toIso8601String(),
      'isOnline': isOnline,
      'lastKnownLocation': lastKnownLocation?.toMap(),
    };
  }

  // Create copy with updated fields
  User copyWith({
    String? name,
    String? email,
    String? phoneNumber,
    String? profileImageUrl,
    String? fcmToken,
    DateTime? lastSeen,
    bool? isOnline,
    RiderLocation? lastKnownLocation,
  }) {
    return User(
      id: id,
      name: name ?? this.name,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      fcmToken: fcmToken ?? this.fcmToken,
      createdAt: createdAt,
      lastSeen: lastSeen ?? this.lastSeen,
      isOnline: isOnline ?? this.isOnline,
      lastKnownLocation: lastKnownLocation ?? this.lastKnownLocation,
    );
  }

  // Helper methods
  String get displayName => name.isNotEmpty ? name : email.split('@').first;
  String get initials {
    List<String> names = name.split(' ');
    if (names.length >= 2) {
      return '${names[0][0]}${names[1][0]}'.toUpperCase();
    }
    return name.isNotEmpty ? name[0].toUpperCase() : email[0].toUpperCase();
  }

  @override
  String toString() {
    return 'User(id: $id, name: $name, email: $email, isOnline: $isOnline)';
  }
}