import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:astra/models/user.dart' as app_user;
import 'package:astra/services/auth_service.dart';
import 'package:astra/utils/constants.dart';

enum AuthStatus {
  uninitialized,
  authenticated,
  unauthenticated,
  authenticating,
}

class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();
  
  AuthStatus _status = AuthStatus.uninitialized;
  app_user.User? _currentUser;
  String? _errorMessage;
  bool _isLoading = false;

  // Getters
  AuthStatus get status => _status;
  app_user.User? get currentUser => _currentUser;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _status == AuthStatus.authenticated && _currentUser != null;
  String? get currentUserId => _currentUser?.id;

  AuthProvider() {
    _initializeAuth();
  }

  // Initialize authentication state
  void _initializeAuth() {
    _authService.authStateChanges.listen((User? firebaseUser) async {
      if (firebaseUser != null) {
        // User is signed in, get user data
        try {
          app_user.User? userData = await _authService.getUserData(firebaseUser.uid);
          if (userData != null) {
            _currentUser = userData;
            _status = AuthStatus.authenticated;
            _errorMessage = null;
          } else {
            // User exists in Firebase Auth but not in Firestore
            await signOut();
          }
        } catch (e) {
          _errorMessage = e.toString();
          _status = AuthStatus.unauthenticated;
        }
      } else {
        // User is signed out
        _currentUser = null;
        _status = AuthStatus.unauthenticated;
        _errorMessage = null;
      }
      notifyListeners();
    });
  }

  // Sign up with email and password
  Future<bool> signUp({
    required String email,
    required String password,
    required String name,
    String? phoneNumber,
  }) async {
    try {
      _setLoading(true);
      _clearError();

      // Validate inputs
      if (name.trim().isEmpty) {
        throw Exception('Name is required');
      }
      if (email.trim().isEmpty) {
        throw Exception('Email is required');
      }
      if (password.length < 6) {
        throw Exception('Password must be at least 6 characters');
      }

      _status = AuthStatus.authenticating;
      notifyListeners();

      // Create account
      app_user.User? user = await _authService.signUpWithEmailAndPassword(
        email: email.trim(),
        password: password,
        name: name.trim(),
        phoneNumber: phoneNumber?.trim(),
      );

      if (user != null) {
        _currentUser = user;
        _status = AuthStatus.authenticated;
        _setLoading(false);
        return true;
      } else {
        throw Exception('Failed to create account');
      }
    } catch (e) {
      _errorMessage = e.toString();
      _status = AuthStatus.unauthenticated;
      _setLoading(false);
      return false;
    }
  }

  // Sign in with email and password
  Future<bool> signIn({
    required String email,
    required String password,
  }) async {
    try {
      _setLoading(true);
      _clearError();

      // Validate inputs
      if (email.trim().isEmpty) {
        throw Exception('Email is required');
      }
      if (password.isEmpty) {
        throw Exception('Password is required');
      }

      _status = AuthStatus.authenticating;
      notifyListeners();

      // Sign in
      app_user.User? user = await _authService.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );

      if (user != null) {
        _currentUser = user;
        _status = AuthStatus.authenticated;
        _setLoading(false);
        return true;
      } else {
        throw Exception('Failed to sign in');
      }
    } catch (e) {
      _errorMessage = e.toString();
      _status = AuthStatus.unauthenticated;
      _setLoading(false);
      return false;
    }
  }

  // Sign out
  Future<void> signOut() async {
    try {
      _setLoading(true);
      await _authService.signOut();
      _currentUser = null;
      _status = AuthStatus.unauthenticated;
      _clearError();
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _setLoading(false);
    }
  }

  // Update user profile
  Future<bool> updateProfile({
    String? name,
    String? phoneNumber,
    String? profileImageUrl,
  }) async {
    try {
      if (_currentUser == null) return false;

      _setLoading(true);
      _clearError();

      // Create updated user object
      app_user.User updatedUser = _currentUser!.copyWith(
        name: name ?? _currentUser!.name,
        phoneNumber: phoneNumber ?? _currentUser!.phoneNumber,
        profileImageUrl: profileImageUrl ?? _currentUser!.profileImageUrl,
      );

      // Update in Firebase
      await _authService.updateUserProfile(updatedUser);
      
      // Update local state
      _currentUser = updatedUser;
      _setLoading(false);
      
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      _setLoading(false);
      return false;
    }
  }

  // Reset password
  Future<bool> resetPassword(String email) async {
    try {
      _setLoading(true);
      _clearError();

      if (email.trim().isEmpty) {
        throw Exception('Email is required');
      }

      await _authService.resetPassword(email.trim());
      _setLoading(false);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      _setLoading(false);
      return false;
    }
  }

  // Delete account
  Future<bool> deleteAccount() async {
    try {
      _setLoading(true);
      _clearError();

      await _authService.deleteAccount();
      
      _currentUser = null;
      _status = AuthStatus.unauthenticated;
      _setLoading(false);
      
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      _setLoading(false);
      return false;
    }
  }

  // Send email verification
  Future<bool> sendEmailVerification() async {
    try {
      _setLoading(true);
      await _authService.sendEmailVerification();
      _setLoading(false);
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      _setLoading(false);
      return false;
    }
  }

  // Check if email is verified
  bool get isEmailVerified => _authService.isEmailVerified;

  // Reload user data
  Future<void> reloadUser() async {
    try {
      if (_currentUser == null) return;
      
      await _authService.reloadUser();
      
      // Refresh user data
      app_user.User? refreshedUser = await _authService.getUserData(_currentUser!.id);
      if (refreshedUser != null) {
        _currentUser = refreshedUser;
        notifyListeners();
      }
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  // Update user's online status
  Future<void> updateOnlineStatus(bool isOnline) async {
    try {
      if (_currentUser == null) return;

      app_user.User updatedUser = _currentUser!.copyWith(
        isOnline: isOnline,
        lastSeen: DateTime.now(),
      );

      await _authService.updateUserProfile(updatedUser);
      _currentUser = updatedUser;
      notifyListeners();
    } catch (e) {
      print('Failed to update online status: ${e.toString()}');
    }
  }

  // Validate email format
  bool isValidEmail(String email) {
    return RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(email);
  }

  // Validate password strength
  Map<String, bool> validatePassword(String password) {
    return {
      'minLength': password.length >= 6,
      'hasUppercase': password.contains(RegExp(r'[A-Z]')),
      'hasLowercase': password.contains(RegExp(r'[a-z]')),
      'hasNumbers': password.contains(RegExp(r'[0-9]')),
      'hasSpecialChars': password.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')),
    };
  }

  // Get password strength score (0-5)
  int getPasswordStrength(String password) {
    Map<String, bool> validation = validatePassword(password);
    return validation.values.where((isValid) => isValid).length;
  }

  // Helper methods
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  void clearError() {
    _clearError();
  }

  @override
  void dispose() {
    super.dispose();
  }
}