import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:astra/models/group.dart';
import 'package:astra/models/location.dart';
import 'package:astra/models/user.dart';
import 'package:astra/services/group_service.dart';
import 'package:astra/services/firebase_service.dart';

enum GroupState {
  idle,
  loading,
  creating,
  joining,
  updating,
  error,
}

class GroupProvider extends ChangeNotifier {
  final GroupService _groupService = GroupService();
  final FirebaseService _firebaseService = FirebaseService();
  
  GroupState _state = GroupState.idle;
  Group? _currentGroup;
  List<Group> _userGroups = [];
  String? _errorMessage;
  StreamSubscription<Group?>? _groupSubscription;
  StreamSubscription<List<Group>>? _userGroupsSubscription;
  Map<String, dynamic>? _groupStatistics;

  // Getters
  GroupState get state => _state;
  Group? get currentGroup => _currentGroup;
  List<Group> get userGroups => List.unmodifiableList(_userGroups);
  String? get errorMessage => _errorMessage;
  bool get isLoading => _state == GroupState.loading || 
                        _state == GroupState.creating || 
                        _state == GroupState.joining ||
                        _state == GroupState.updating;
  bool get hasCurrentGroup => _currentGroup != null;
  bool get isInActiveGroup => _currentGroup?.isActive ?? false;
  bool get isGroupLeader => _currentGroup?.isUserLeader(_firebaseService.currentUserId ?? '') ?? false;
  Map<String, dynamic>? get groupStatistics => _groupStatistics;

  // Current group helpers
  int get currentGroupMemberCount => _currentGroup?.memberCount ?? 0;
  int get currentGroupOnlineCount => _currentGroup?.onlineMembers.length ?? 0;
  String get currentGroupStatus => _currentGroup?.status.name ?? 'unknown';
  bool get hasDestination => _currentGroup?.destination != null;
  int get suggestedStopsCount => _currentGroup?.suggestedStops.length ?? 0;
  int get approvedStopsCount => _currentGroup?.approvedStops.length ?? 0;

  // Create new group
  Future<bool> createGroup({
    required String name,
    required String description,
    required User leader,
  }) async {
    try {
      _setState(GroupState.creating);
      _clearError();

      // Validate inputs
      if (name.trim().isEmpty) {
        throw Exception('Group name is required');
      }
      if (leader.id.isEmpty) {
        throw Exception('Invalid user data');
      }

      // Create group
      Group group = await _groupService.createGroup(
        name: name.trim(),
        description: description.trim(),
        leader: leader,
      );

      // Set as current group and start listening
      await setCurrentGroup(group.id);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Join group by code
  Future<bool> joinGroup(String joinCode, User user) async {
    try {
      _setState(GroupState.joining);
      _clearError();

      // Validate join code
      if (!_groupService.isValidJoinCode(joinCode.toUpperCase())) {
        throw Exception('Invalid join code format');
      }

      // Join group
      Group group = await _groupService.joinGroupByCode(joinCode.toUpperCase(), user);
      
      // Set as current group and start listening
      await setCurrentGroup(group.id);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Set current group and start listening for updates
  Future<void> setCurrentGroup(String groupId) async {
    try {
      // Cancel existing subscription
      await _groupSubscription?.cancel();
      
      // Start listening to group updates
      _groupSubscription = _firebaseService.getGroupStream(groupId).listen(
        (Group? group) {
          _currentGroup = group;
          if (group != null) {
            _updateGroupStatistics();
          }
          notifyListeners();
        },
        onError: (error) {
          _errorMessage = error.toString();
          _setState(GroupState.error);
        },
      );
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
    }
  }

  // Load user's groups
  Future<void> loadUserGroups(String userId) async {
    try {
      // Cancel existing subscription
      await _userGroupsSubscription?.cancel();
      
      // Start listening to user's groups
      _userGroupsSubscription = _firebaseService.getUserGroups(userId).listen(
        (List<Group> groups) {
          _userGroups = groups;
          notifyListeners();
        },
        onError: (error) {
          print('Error loading user groups: ${error.toString()}');
        },
      );
      
    } catch (e) {
      print('Failed to load user groups: ${e.toString()}');
    }
  }

  // Leave current group
  Future<bool> leaveGroup(String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.leaveGroup(_currentGroup!.id, userId);
      
      // Clear current group
      _currentGroup = null;
      await _groupSubscription?.cancel();
      _groupSubscription = null;
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Update destination (leader only)
  Future<bool> updateDestination(RiderLocation destination, String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.updateDestination(_currentGroup!.id, destination, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Suggest stop
  Future<bool> suggestStop(RiderLocation stop, String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.suggestStop(_currentGroup!.id, stop, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Approve stop (leader only)
  Future<bool> approveStop(RiderLocation stop, String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.approveStop(_currentGroup!.id, stop, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Reject stop (leader only)
  Future<bool> rejectStop(RiderLocation stop, String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.rejectStop(_currentGroup!.id, stop, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Start ride (leader only)
  Future<bool> startRide(String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.startRide(_currentGroup!.id, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Pause ride (leader only)
  Future<bool> pauseRide(String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.pauseRide(_currentGroup!.id, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Resume ride (leader only)
  Future<bool> resumeRide(String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.resumeRide(_currentGroup!.id, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Complete ride (leader only)
  Future<bool> completeRide(String userId) async {
    try {
      if (_currentGroup == null) return false;
      
      _setState(GroupState.updating);
      _clearError();

      await _groupService.completeRide(_currentGroup!.id, userId);
      
      _setState(GroupState.idle);
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      _setState(GroupState.error);
      return false;
    }
  }

  // Update member location
  Future<void> updateMemberLocation(String userId, RiderLocation location) async {
    try {
      if (_currentGroup == null) return;
      
      await _groupService.updateMemberLocation(_currentGroup!.id, userId, location);
      
    } catch (e) {
      print('Failed to update member location: ${e.toString()}');
    }
  }

  // Send emergency alert
  Future<bool> sendEmergencyAlert(String userId, RiderLocation location, EmergencyType emergencyType) async {
    try {
      if (_currentGroup == null) return false;
      
      await _groupService.sendEmergencyAlert(_currentGroup!.id, userId, location, emergencyType);
      
      return true;
      
    } catch (e) {
      _errorMessage = e.toString();
      return false;
    }
  }

  // Update group statistics
  Future<void> _updateGroupStatistics() async {
    try {
      if (_currentGroup == null) return;
      
      _groupStatistics = await _groupService.getGroupStatistics(_currentGroup!.id);
      
    } catch (e) {
      print('Failed to update group statistics: ${e.toString()}');
    }
  }

  // Get member by user ID
  GroupMember? getMember(String userId) {
    return _currentGroup?.members.firstWhere(
      (member) => member.userId == userId,
      orElse: () => _currentGroup!.members.first,
    );
  }

  // Check if user can perform specific action
  bool canUserPerformAction(String userId, String action) {
    if (_currentGroup == null) return false;
    return _groupService.canUserPerformAction(_currentGroup!, userId, action);
  }

  // Get group member locations
  List<RiderLocation> getMemberLocations() {
    if (_currentGroup == null) return [];
    
    return _currentGroup!.members
        .where((member) => member.currentLocation != null)
        .map((member) => member.currentLocation!)
        .toList();
  }

  // Get emergency alerts
  List<GroupMember> getEmergencyAlerts() {
    if (_currentGroup == null) return [];
    
    return _currentGroup!.members
        .where((member) => member.currentLocation?.isEmergency ?? false)
        .toList();
  }

  // Search groups by name (for future feature)
  Future<List<Group>> searchGroups(String query) async {
    try {
      // TODO: Implement group search when backend supports it
      return [];
    } catch (e) {
      return [];
    }
  }

  // Get group activity summary
  Map<String, dynamic> getGroupActivitySummary() {
    if (_currentGroup == null) return {};
    
    DateTime now = DateTime.now();
    List<GroupMember> recentlyActive = _currentGroup!.members
        .where((member) => 
          member.lastLocationUpdate != null &&
          now.difference(member.lastLocationUpdate!).inMinutes < 10)
        .toList();
    
    return {
      'totalMembers': _currentGroup!.memberCount,
      'onlineMembers': _currentGroup!.onlineMembers.length,
      'recentlyActive': recentlyActive.length,
      'hasEmergencies': getEmergencyAlerts().isNotEmpty,
      'emergencyCount': getEmergencyAlerts().length,
      'status': _currentGroup!.status.name,
      'hasDestination': _currentGroup!.destination != null,
      'stopsSuggested': _currentGroup!.suggestedStops.length,
      'stopsApproved': _currentGroup!.approvedStops.length,
      'rideDuration': _currentGroup!.rideDuration?.inMinutes ?? 0,
    };
  }

  // Filter groups by status
  List<Group> getGroupsByStatus(GroupStatus status) {
    return _userGroups.where((group) => group.status == status).toList();
  }

  // Get active groups
  List<Group> get activeGroups => getGroupsByStatus(GroupStatus.active);
  
  // Get completed groups
  List<Group> get completedGroups => getGroupsByStatus(GroupStatus.completed);
  
  // Get planning groups
  List<Group> get planningGroups => getGroupsByStatus(GroupStatus.planning);

  // Clear current group
  void clearCurrentGroup() {
    _currentGroup = null;
    _groupSubscription?.cancel();
    _groupSubscription = null;
    _groupStatistics = null;
    notifyListeners();
  }

  // Refresh current group
  Future<void> refreshCurrentGroup() async {
    if (_currentGroup != null) {
      await setCurrentGroup(_currentGroup!.id);
    }
  }

  // Helper methods
  void _setState(GroupState newState) {
    _state = newState;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
  }

  void clearError() {
    _clearError();
    notifyListeners();
  }

  // Get state message for UI
  String getStateMessage() {
    switch (_state) {
      case GroupState.idle:
        return '';
      case GroupState.loading:
        return 'Loading...';
      case GroupState.creating:
        return 'Creating group...';
      case GroupState.joining:
        return 'Joining group...';
      case GroupState.updating:
        return 'Updating...';
      case GroupState.error:
        return _errorMessage ?? 'An error occurred';
    }
  }

  @override
  void dispose() {
    _groupSubscription?.cancel();
    _userGroupsSubscription?.cancel();
    super.dispose();
  }
}