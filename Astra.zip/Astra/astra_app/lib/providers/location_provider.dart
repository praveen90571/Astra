import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:astra/models/location.dart';
import 'package:astra/services/location_service.dart';
import 'package:astra/utils/constants.dart';

enum LocationStatus {
  uninitialized,
  permissionDenied,
  serviceDisabled,
  tracking,
  stopped,
  error,
}

class LocationProvider extends ChangeNotifier {
  final LocationService _locationService = LocationService();
  
  LocationStatus _status = LocationStatus.uninitialized;
  RiderLocation? _currentLocation;
  List<RiderLocation> _locationHistory = [];
  String? _errorMessage;
  bool _isTracking = false;
  StreamSubscription<RiderLocation>? _locationSubscription;
  Timer? _locationTimer;

  // Getters
  LocationStatus get status => _status;
  RiderLocation? get currentLocation => _currentLocation;
  List<RiderLocation> get locationHistory => List.unmodifiableList(_locationHistory);
  String? get errorMessage => _errorMessage;
  bool get isTracking => _isTracking;
  bool get hasLocation => _currentLocation != null;
  bool get hasPermission => _status != LocationStatus.permissionDenied;
  bool get isServiceEnabled => _status != LocationStatus.serviceDisabled;

  // Location accuracy status
  String get accuracyStatus {
    if (_currentLocation?.accuracy == null) return 'Unknown';
    return _locationService.getLocationAccuracyStatus(_currentLocation!.accuracy);
  }

  // Current speed
  String get currentSpeed {
    return _currentLocation?.speedKmh ?? 'N/A';
  }

  // Distance traveled
  double get totalDistance {
    if (_locationHistory.length < 2) return 0.0;
    
    double total = 0.0;
    for (int i = 1; i < _locationHistory.length; i++) {
      total += _locationHistory[i-1].distanceTo(_locationHistory[i]);
    }
    return total;
  }

  // Formatted distance
  String get totalDistanceFormatted {
    double distance = totalDistance;
    if (distance < 1000) {
      return '${distance.toStringAsFixed(0)} m';
    } else {
      return '${(distance / 1000).toStringAsFixed(1)} km';
    }
  }

  // Initialize location services
  Future<void> initialize() async {
    try {
      _clearError();
      
      // Check if service is enabled
      bool serviceEnabled = await _locationService.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _status = LocationStatus.serviceDisabled;
        _errorMessage = 'Location services are disabled';
        notifyListeners();
        return;
      }

      // Request permissions
      bool hasPermission = await _locationService.requestLocationPermission();
      if (!hasPermission) {
        _status = LocationStatus.permissionDenied;
        _errorMessage = 'Location permission denied';
        notifyListeners();
        return;
      }

      _status = LocationStatus.stopped;
      notifyListeners();
      
    } catch (e) {
      _status = LocationStatus.error;
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  // Get current location once
  Future<RiderLocation?> getCurrentLocation() async {
    try {
      _clearError();
      
      if (_status == LocationStatus.permissionDenied) {
        await initialize();
        if (_status == LocationStatus.permissionDenied) {
          return null;
        }
      }

      RiderLocation location = await _locationService.getCurrentLocation();
      _updateCurrentLocation(location);
      return location;
      
    } catch (e) {
      _status = LocationStatus.error;
      _errorMessage = e.toString();
      notifyListeners();
      return null;
    }
  }

  // Start continuous location tracking
  Future<bool> startTracking({String? userId}) async {
    try {
      if (_isTracking) return true;
      
      _clearError();
      
      // Ensure we have permissions
      if (_status == LocationStatus.uninitialized || 
          _status == LocationStatus.permissionDenied ||
          _status == LocationStatus.serviceDisabled) {
        await initialize();
        if (_status != LocationStatus.stopped) {
          return false;
        }
      }

      // Start location service
      await _locationService.startLocationTracking(userId: userId);
      
      // Subscribe to location updates
      _locationSubscription = _locationService.locationStream.listen(
        (RiderLocation location) {
          _updateCurrentLocation(location);
        },
        onError: (error) {
          _status = LocationStatus.error;
          _errorMessage = error.toString();
          notifyListeners();
        },
      );

      _isTracking = true;
      _status = LocationStatus.tracking;
      
      // Start periodic updates (backup for location stream)
      _startPeriodicUpdates(userId);
      
      notifyListeners();
      return true;
      
    } catch (e) {
      _status = LocationStatus.error;
      _errorMessage = e.toString();
      _isTracking = false;
      notifyListeners();
      return false;
    }
  }

  // Stop location tracking
  Future<void> stopTracking() async {
    try {
      await _locationService.stopLocationTracking();
      await _locationSubscription?.cancel();
      _locationSubscription = null;
      
      _locationTimer?.cancel();
      _locationTimer = null;
      
      _isTracking = false;
      _status = LocationStatus.stopped;
      
      notifyListeners();
      
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  // Update current location
  void _updateCurrentLocation(RiderLocation location) {
    _currentLocation = location;
    
    // Add to history if it's a significant movement
    if (_locationHistory.isEmpty || 
        _locationHistory.last.distanceTo(location) > AppConstants.minDistanceFilter) {
      _locationHistory.add(location);
      
      // Keep history size manageable (last 1000 points)
      if (_locationHistory.length > 1000) {
        _locationHistory.removeAt(0);
      }
    }
    
    notifyListeners();
  }

  // Start periodic location updates (backup mechanism)
  void _startPeriodicUpdates(String? userId) {
    _locationTimer = Timer.periodic(
      Duration(seconds: AppConstants.locationUpdateInterval.toInt()),
      (timer) async {
        if (!_isTracking) {
          timer.cancel();
          return;
        }
        
        // This serves as a backup - the main updates come from the stream
        // But this ensures we don't miss updates due to stream issues
        try {
          if (_locationService.lastKnownLocation != null) {
            RiderLocation lastKnown = _locationService.lastKnownLocation!;
            if (_currentLocation == null || 
                _currentLocation!.timestamp.isBefore(lastKnown.timestamp)) {
              _updateCurrentLocation(lastKnown);
            }
          }
        } catch (e) {
          print('Periodic location update error: ${e.toString()}');
        }
      },
    );
  }

  // Calculate distance to a specific location
  double distanceTo(RiderLocation destination) {
    if (_currentLocation == null) return 0.0;
    return _currentLocation!.distanceTo(destination);
  }

  // Calculate bearing to a specific location
  double bearingTo(RiderLocation destination) {
    if (_currentLocation == null) return 0.0;
    return _locationService.calculateBearing(_currentLocation!, destination);
  }

  // Check if current location is near another location
  bool isNear(RiderLocation location, double radiusInMeters) {
    if (_currentLocation == null) return false;
    return _locationService.isLocationNearby(_currentLocation!, location, radiusInMeters);
  }

  // Get location history for a specific time range
  List<RiderLocation> getLocationHistory({
    DateTime? startTime,
    DateTime? endTime,
  }) {
    List<RiderLocation> filtered = _locationHistory;
    
    if (startTime != null) {
      filtered = filtered.where((loc) => loc.timestamp.isAfter(startTime)).toList();
    }
    
    if (endTime != null) {
      filtered = filtered.where((loc) => loc.timestamp.isBefore(endTime)).toList();
    }
    
    return filtered;
  }

  // Clear location history
  void clearHistory() {
    _locationHistory.clear();
    notifyListeners();
  }

  // Create emergency location
  RiderLocation? createEmergencyLocation(EmergencyType emergencyType, String description) {
    if (_currentLocation == null) return null;
    
    return _currentLocation!.copyWith(
      type: LocationType.emergency,
      emergencyType: emergencyType,
      description: description,
      timestamp: DateTime.now(),
    );
  }

  // Open location settings
  Future<void> openLocationSettings() async {
    await _locationService.openLocationSettings();
  }

  // Retry location initialization
  Future<void> retry() async {
    await initialize();
  }

  // Helper methods
  void _clearError() {
    _errorMessage = null;
  }

  void clearError() {
    _clearError();
    notifyListeners();
  }

  // Get location status message
  String getStatusMessage() {
    switch (_status) {
      case LocationStatus.uninitialized:
        return 'Initializing location services...';
      case LocationStatus.permissionDenied:
        return 'Location permission denied. Please enable in settings.';
      case LocationStatus.serviceDisabled:
        return 'Location services disabled. Please enable in settings.';
      case LocationStatus.tracking:
        return 'Location tracking active';
      case LocationStatus.stopped:
        return 'Location tracking stopped';
      case LocationStatus.error:
        return _errorMessage ?? 'Location error occurred';
    }
  }

  @override
  void dispose() {
    stopTracking();
    _locationTimer?.cancel();
    super.dispose();
  }
}