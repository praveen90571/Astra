import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:astra/providers/auth_provider.dart';
import 'package:astra/providers/group_provider.dart';
import 'package:astra/providers/location_provider.dart';
import 'package:astra/models/group.dart';
import 'package:astra/screens/group/create_group_screen.dart';
import 'package:astra/screens/group/join_group_screen.dart';
import 'package:astra/screens/group/group_details_screen.dart';
import 'package:astra/screens/map/map_screen.dart';
import 'package:astra/screens/profile/profile_screen.dart';
import 'package:astra/widgets/common/custom_button.dart';
import 'package:astra/config/theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  
  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  void _initializeApp() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    
    // Initialize location services
    await locationProvider.initialize();
    
    // Load user's groups
    if (authProvider.currentUserId != null) {
      groupProvider.loadUserGroups(authProvider.currentUserId!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: const [
          _HomeTab(),
          MapScreen(),
          _GroupsTab(),
          ProfileScreen(),
        ],
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildBottomNavigationBar() {
    return Consumer<GroupProvider>(
      builder: (context, groupProvider, child) {
        return BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          items: [
            const BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Stack(
                children: [
                  const Icon(Icons.map),
                  if (groupProvider.hasCurrentGroup && groupProvider.isInActiveGroup)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Colors.green,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                ],
              ),
              label: 'Map',
            ),
            BottomNavigationBarItem(
              icon: Stack(
                children: [
                  const Icon(Icons.group),
                  if (groupProvider.userGroups.isNotEmpty)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: const BoxDecoration(
                          color: AppTheme.primaryColor,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          '${groupProvider.userGroups.length}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              ),
              label: 'Groups',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile',
            ),
          ],
        );
      },
    );
  }
}

class _HomeTab extends StatelessWidget {
  const _HomeTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Astra'),
        actions: [
          Consumer<AuthProvider>(
            builder: (context, authProvider, child) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: CircleAvatar(
                  backgroundColor: Colors.white,
                  child: Text(
                    authProvider.currentUser?.initials ?? 'U',
                    style: const TextStyle(
                      color: AppTheme.primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Section
            _buildWelcomeSection(),
            
            const SizedBox(height: 24),
            
            // Current Group Status
            _buildCurrentGroupStatus(),
            
            const SizedBox(height: 24),
            
            // Quick Actions
            _buildQuickActions(),
            
            const SizedBox(height: 24),
            
            // Recent Groups
            _buildRecentGroups(),
            
            const SizedBox(height: 24),
            
            // Location Status
            _buildLocationStatus(),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeSection() {
    return Consumer<AuthProvider>(
      builder: (context, authProvider, child) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Welcome back, ${authProvider.currentUser?.displayName ?? 'Rider'}!',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  'Ready for your next group ride?',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildCurrentGroupStatus() {
    return Consumer<GroupProvider>(
      builder: (context, groupProvider, child) {
        if (!groupProvider.hasCurrentGroup) {
          return _buildNoGroupCard();
        }

        return _buildActiveGroupCard(groupProvider.currentGroup!);
      },
    );
  }

  Widget _buildNoGroupCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.group_off,
                  color: AppTheme.textSecondary,
                  size: 32,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'No Active Group',
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      Text(
                        'Create or join a group to start riding together',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: CustomButton(
                    text: 'Create Group',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const CreateGroupScreen(),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: CustomButton(
                    text: 'Join Group',
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const JoinGroupScreen(),
                        ),
                      );
                    },
                    variant: ButtonVariant.outlined,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActiveGroupCard(Group group) {
    return Card(
      color: AppTheme.primaryColor.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: _getStatusColor(group.status).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    _getStatusIcon(group.status),
                    color: _getStatusColor(group.status),
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        group.name,
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                      Text(
                        _getStatusText(group.status),
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: _getStatusColor(group.status),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _buildGroupStat(
                  icon: Icons.people,
                  label: 'Members',
                  value: '${group.onlineMembers.length}/${group.memberCount}',
                ),
                const SizedBox(width: 20),
                _buildGroupStat(
                  icon: Icons.location_on,
                  label: 'Destination',
                  value: group.destination != null ? 'Set' : 'None',
                ),
                const SizedBox(width: 20),
                if (group.rideDuration != null)
                  _buildGroupStat(
                    icon: Icons.timer,
                    label: 'Duration',
                    value: _formatDuration(group.rideDuration!),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            CustomButton(
              text: 'View Group',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => GroupDetailsScreen(group: group),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGroupStat({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Column(
      children: [
        Icon(icon, size: 20, color: AppTheme.textSecondary),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Actions',
          style: Theme.of(context).textTheme.headlineMedium,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildQuickActionCard(
                icon: Icons.add_circle,
                title: 'Create Group',
                subtitle: 'Start a new ride',
                color: AppTheme.primaryColor,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const CreateGroupScreen(),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildQuickActionCard(
                icon: Icons.group_add,
                title: 'Join Group',
                subtitle: 'Enter group code',
                color: AppTheme.accentColor,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const JoinGroupScreen(),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 32,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 12,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentGroups() {
    return Consumer<GroupProvider>(
      builder: (context, groupProvider, child) {
        if (groupProvider.userGroups.isEmpty) {
          return const SizedBox.shrink();
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Groups',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 16),
            ...groupProvider.userGroups.take(3).map((group) => 
              _buildGroupListItem(group)),
            if (groupProvider.userGroups.length > 3)
              TextButton(
                onPressed: () {
                  // Switch to groups tab
                },
                child: const Text('View All Groups'),
              ),
          ],
        );
      },
    );
  }

  Widget _buildGroupListItem(Group group) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: _getStatusColor(group.status).withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            _getStatusIcon(group.status),
            color: _getStatusColor(group.status),
          ),
        ),
        title: Text(group.name),
        subtitle: Text(
          '${group.memberCount} members • ${_getStatusText(group.status)}',
        ),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => GroupDetailsScreen(group: group),
            ),
          );
        },
      ),
    );
  }

  Widget _buildLocationStatus() {
    return Consumer<LocationProvider>(
      builder: (context, locationProvider, child) {
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      _getLocationIcon(locationProvider.status),
                      color: _getLocationColor(locationProvider.status),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Location Status',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  locationProvider.getStatusMessage(),
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                if (locationProvider.hasLocation) ...[
                  const SizedBox(height: 8),
                  Text(
                    'Speed: ${locationProvider.currentSpeed} • Accuracy: ${locationProvider.accuracyStatus}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
                if (locationProvider.status == LocationStatus.permissionDenied ||
                    locationProvider.status == LocationStatus.serviceDisabled) ...[
                  const SizedBox(height: 12),
                  CustomButton(
                    text: 'Enable Location',
                    onPressed: () => locationProvider.openLocationSettings(),
                    variant: ButtonVariant.outlined,
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }

  // Helper methods
  Color _getStatusColor(GroupStatus status) {
    switch (status) {
      case GroupStatus.active:
        return AppTheme.successColor;
      case GroupStatus.paused:
        return Colors.orange;
      case GroupStatus.completed:
        return Colors.blue;
      case GroupStatus.planning:
        return AppTheme.primaryColor;
      case GroupStatus.cancelled:
        return AppTheme.errorColor;
    }
  }

  IconData _getStatusIcon(GroupStatus status) {
    switch (status) {
      case GroupStatus.active:
        return Icons.directions_bike;
      case GroupStatus.paused:
        return Icons.pause;
      case GroupStatus.completed:
        return Icons.check_circle;
      case GroupStatus.planning:
        return Icons.schedule;
      case GroupStatus.cancelled:
        return Icons.cancel;
    }
  }

  String _getStatusText(GroupStatus status) {
    switch (status) {
      case GroupStatus.active:
        return 'Riding Now';
      case GroupStatus.paused:
        return 'On Break';
      case GroupStatus.completed:
        return 'Completed';
      case GroupStatus.planning:
        return 'Planning';
      case GroupStatus.cancelled:
        return 'Cancelled';
    }
  }

  IconData _getLocationIcon(LocationStatus status) {
    switch (status) {
      case LocationStatus.tracking:
        return Icons.my_location;
      case LocationStatus.stopped:
        return Icons.location_off;
      case LocationStatus.permissionDenied:
        return Icons.location_disabled;
      case LocationStatus.serviceDisabled:
        return Icons.location_disabled;
      case LocationStatus.error:
        return Icons.error;
      case LocationStatus.uninitialized:
        return Icons.location_searching;
    }
  }

  Color _getLocationColor(LocationStatus status) {
    switch (status) {
      case LocationStatus.tracking:
        return AppTheme.successColor;
      case LocationStatus.stopped:
        return Colors.orange;
      case LocationStatus.permissionDenied:
      case LocationStatus.serviceDisabled:
      case LocationStatus.error:
        return AppTheme.errorColor;
      case LocationStatus.uninitialized:
        return AppTheme.textSecondary;
    }
  }

  String _formatDuration(Duration duration) {
    int hours = duration.inHours;
    int minutes = duration.inMinutes.remainder(60);
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    } else {
      return '${minutes}m';
    }
  }
}

class _GroupsTab extends StatelessWidget {
  const _GroupsTab();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Groups'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () {
              _showCreateJoinDialog(context);
            },
          ),
        ],
      ),
      body: Consumer<GroupProvider>(
        builder: (context, groupProvider, child) {
          if (groupProvider.userGroups.isEmpty) {
            return _buildEmptyState(context);
          }

          return _buildGroupsList(context, groupProvider.userGroups);
        },
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.group_off,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 24),
            Text(
              'No Groups Yet',
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Create or join a group to start riding with others',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey.shade500,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomButton(
                  text: 'Create Group',
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const CreateGroupScreen(),
                      ),
                    );
                  },
                ),
                const SizedBox(width: 16),
                CustomButton(
                  text: 'Join Group',
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const JoinGroupScreen(),
                      ),
                    );
                  },
                  variant: ButtonVariant.outlined,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGroupsList(BuildContext context, List<Group> groups) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: groups.length,
      itemBuilder: (context, index) {
        final group = groups[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor(group.status).withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                _getStatusIcon(group.status),
                color: _getStatusColor(group.status),
              ),
            ),
            title: Text(
              group.name,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Text(group.description),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.people, size: 16, color: Colors.grey.shade600),
                    const SizedBox(width: 4),
                    Text('${group.memberCount} members'),
                    const SizedBox(width: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: _getStatusColor(group.status).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        _getStatusText(group.status),
                        style: TextStyle(
                          color: _getStatusColor(group.status),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => GroupDetailsScreen(group: group),
                ),
              );
            },
          ),
        );
      },
    );
  }

  void _showCreateJoinDialog(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Group Options',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: CustomButton(
                    text: 'Create Group',
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const CreateGroupScreen(),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: CustomButton(
                    text: 'Join Group',
                    onPressed: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const JoinGroupScreen(),
                        ),
                      );
                    },
                    variant: ButtonVariant.outlined,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  // Helper methods (same as in _HomeTab)
  Color _getStatusColor(GroupStatus status) {
    switch (status) {
      case GroupStatus.active:
        return AppTheme.successColor;
      case GroupStatus.paused:
        return Colors.orange;
      case GroupStatus.completed:
        return Colors.blue;
      case GroupStatus.planning:
        return AppTheme.primaryColor;
      case GroupStatus.cancelled:
        return AppTheme.errorColor;
    }
  }

  IconData _getStatusIcon(GroupStatus status) {
    switch (status) {
      case GroupStatus.active:
        return Icons.directions_bike;
      case GroupStatus.paused:
        return Icons.pause;
      case GroupStatus.completed:
        return Icons.check_circle;
      case GroupStatus.planning:
        return Icons.schedule;
      case GroupStatus.cancelled:
        return Icons.cancel;
    }
  }

  String _getStatusText(GroupStatus status) {
    switch (status) {
      case GroupStatus.active:
        return 'Active';
      case GroupStatus.paused:
        return 'Paused';
      case GroupStatus.completed:
        return 'Completed';
      case GroupStatus.planning:
        return 'Planning';
      case GroupStatus.cancelled:
        return 'Cancelled';
    }
  }
}