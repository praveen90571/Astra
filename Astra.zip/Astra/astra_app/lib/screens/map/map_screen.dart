import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:astra/providers/auth_provider.dart';
import 'package:astra/providers/group_provider.dart';
import 'package:astra/providers/location_provider.dart';
import 'package:astra/models/location.dart';
import 'package:astra/models/group.dart';
import 'package:astra/services/map_service.dart';
import 'package:astra/config/theme.dart';
import 'package:astra/widgets/map/rider_marker.dart';
import 'package:astra/widgets/common/custom_button.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final Completer<GoogleMapController> _controller = Completer();
  final MapService _mapService = MapService();
  
  Set<Marker> _markers = {};
  Set<Polyline> _polylines = {};
  Timer? _locationUpdateTimer;
  bool _isTrackingLocation = false;
  bool _showMembersList = false;

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  @override
  void dispose() {
    _locationUpdateTimer?.cancel();
    super.dispose();
  }

  void _initializeMap() async {
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    
    // Initialize location if not already done
    if (locationProvider.status == LocationStatus.uninitialized) {
      await locationProvider.initialize();
    }

    // Start location tracking if we have a group
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    if (groupProvider.hasCurrentGroup) {
      _startLocationTracking();
    }
  }

  void _startLocationTracking() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);

    if (authProvider.currentUserId == null || !groupProvider.hasCurrentGroup) {
      return;
    }

    // Start location tracking
    bool success = await locationProvider.startTracking(
      userId: authProvider.currentUserId!,
    );

    if (success) {
      setState(() {
        _isTrackingLocation = true;
      });

      // Update group with location every 5 seconds
      _locationUpdateTimer = Timer.periodic(
        const Duration(seconds: 5),
        (timer) async {
          if (locationProvider.currentLocation != null) {
            await groupProvider.updateMemberLocation(
              authProvider.currentUserId!,
              locationProvider.currentLocation!,
            );
          }
        },
      );
    }
  }

  void _stopLocationTracking() async {
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    
    await locationProvider.stopTracking();
    _locationUpdateTimer?.cancel();
    
    setState(() {
      _isTrackingLocation = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Map'),
        actions: [
          Consumer<GroupProvider>(
            builder: (context, groupProvider, child) {
              if (!groupProvider.hasCurrentGroup) return const SizedBox.shrink();
              
              return Row(
                children: [
                  // Members list toggle
                  IconButton(
                    icon: Icon(_showMembersList ? Icons.list : Icons.people),
                    onPressed: () {
                      setState(() {
                        _showMembersList = !_showMembersList;
                      });
                    },
                  ),
                  // Center on group
                  IconButton(
                    icon: const Icon(Icons.center_focus_strong),
                    onPressed: _centerOnGroup,
                  ),
                ],
              );
            },
          ),
        ],
      ),
      body: Consumer3<GroupProvider, LocationProvider, AuthProvider>(
        builder: (context, groupProvider, locationProvider, authProvider, child) {
          return Stack(
            children: [
              // Map
              _buildMap(groupProvider, locationProvider, authProvider),
              
              // No group overlay
              if (!groupProvider.hasCurrentGroup)
                _buildNoGroupOverlay(),
              
              // Location status banner
              if (locationProvider.status != LocationStatus.tracking)
                _buildLocationStatusBanner(locationProvider),
              
              // Members list overlay
              if (_showMembersList && groupProvider.hasCurrentGroup)
                _buildMembersListOverlay(groupProvider.currentGroup!),
              
              // Emergency alert banner
              if (groupProvider.hasCurrentGroup)
                _buildEmergencyAlertBanner(groupProvider.currentGroup!),
              
              // Bottom controls
              _buildBottomControls(groupProvider, locationProvider, authProvider),
            ],
          );
        },
      ),
    );
  }

  Widget _buildMap(GroupProvider groupProvider, LocationProvider locationProvider, AuthProvider authProvider) {
    return GoogleMap(
      mapType: MapType.normal,
      initialCameraPosition: const CameraPosition(
        target: LatLng(37.7749, -122.4194), // Default to San Francisco
        zoom: 14.0,
      ),
      onMapCreated: (GoogleMapController controller) {
        _controller.complete(controller);
        _updateMapWithLocations();
      },
      markers: _markers,
      polylines: _polylines,
      myLocationEnabled: true,
      myLocationButtonEnabled: false, // We'll use custom button
      compassEnabled: true,
      trafficEnabled: false,
      buildingsEnabled: true,
      indoorViewEnabled: false,
      mapToolbarEnabled: false,
      zoomControlsEnabled: false,
      rotateGesturesEnabled: true,
      scrollGesturesEnabled: true,
      tiltGesturesEnabled: true,
      zoomGesturesEnabled: true,
      minMaxZoomPreference: const MinMaxZoomPreference(8.0, 20.0),
    );
  }

  Widget _buildNoGroupOverlay() {
    return Container(
      color: Colors.black54,
      child: Center(
        child: Card(
          margin: const EdgeInsets.all(32),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.group_off,
                  size: 64,
                  color: Colors.grey.shade600,
                ),
                const SizedBox(height: 16),
                Text(
                  'No Active Group',
                  style: Theme.of(context).textTheme.headlineMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                Text(
                  'Join or create a group to see member locations on the map',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                CustomButton(
                  text: 'Go to Groups',
                  onPressed: () {
                    // This would switch to groups tab in parent
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLocationStatusBanner(LocationProvider locationProvider) {
    if (locationProvider.status == LocationStatus.tracking) {
      return const SizedBox.shrink();
    }

    Color backgroundColor;
    IconData icon;
    String message;

    switch (locationProvider.status) {
      case LocationStatus.permissionDenied:
        backgroundColor = Colors.red;
        icon = Icons.location_disabled;
        message = 'Location permission required';
        break;
      case LocationStatus.serviceDisabled:
        backgroundColor = Colors.orange;
        icon = Icons.location_off;
        message = 'Location services disabled';
        break;
      case LocationStatus.error:
        backgroundColor = Colors.red;
        icon = Icons.error;
        message = locationProvider.errorMessage ?? 'Location error';
        break;
      default:
        backgroundColor = Colors.blue;
        icon = Icons.location_searching;
        message = 'Getting location...';
    }

    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: Container(
        color: backgroundColor,
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(color: Colors.white),
              ),
            ),
            if (locationProvider.status == LocationStatus.permissionDenied ||
                locationProvider.status == LocationStatus.serviceDisabled)
              TextButton(
                onPressed: () => locationProvider.openLocationSettings(),
                child: const Text(
                  'Settings',
                  style: TextStyle(color: Colors.white),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMembersListOverlay(Group group) {
    return Positioned(
      top: 80,
      right: 16,
      child: Container(
        width: 300,
        constraints: const BoxConstraints(maxHeight: 400),
        child: Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const Icon(Icons.people),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Group Members',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        setState(() {
                          _showMembersList = false;
                        });
                      },
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: group.members.length,
                  itemBuilder: (context, index) {
                    final member = group.members[index];
                    return _buildMemberListItem(member);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMemberListItem(GroupMember member) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: member.isOnline ? AppTheme.successColor : Colors.grey,
        child: Icon(
          member.role == MemberRole.leader ? Icons.star : Icons.person,
          color: Colors.white,
          size: 16,
        ),
      ),
      title: Text(
        member.name,
        style: TextStyle(
          fontWeight: member.role == MemberRole.leader 
              ? FontWeight.bold 
              : FontWeight.normal,
        ),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            member.role == MemberRole.leader ? 'Leader' : 'Member',
            style: const TextStyle(fontSize: 12),
          ),
          if (member.currentLocation != null)
            Text(
              'Speed: ${member.currentLocation!.speedKmh}',
              style: const TextStyle(fontSize: 10),
            ),
        ],
      ),
      trailing: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: member.isOnline ? AppTheme.successColor : Colors.grey,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(height: 4),
          if (member.currentLocation?.isEmergency == true)
            const Icon(
              Icons.warning,
              color: AppTheme.emergencyColor,
              size: 16,
            ),
        ],
      ),
      onTap: () {
        if (member.currentLocation != null) {
          _centerOnLocation(LatLng(
            member.currentLocation!.latitude,
            member.currentLocation!.longitude,
          ));
        }
      },
    );
  }

  Widget _buildEmergencyAlertBanner(Group group) {
    final emergencyMembers = group.members
        .where((member) => member.currentLocation?.isEmergency == true)
        .toList();

    if (emergencyMembers.isEmpty) {
      return const SizedBox.shrink();
    }

    return Positioned(
      top: 80,
      left: 16,
      right: 16,
      child: Card(
        color: AppTheme.emergencyColor,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.warning,
                    color: Colors.white,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'EMERGENCY ALERT',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ...emergencyMembers.map((member) => Text(
                '${member.name}: ${member.currentLocation!.emergencyType?.name ?? 'Emergency'}',
                style: const TextStyle(color: Colors.white),
              )),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomControls(GroupProvider groupProvider, LocationProvider locationProvider, AuthProvider authProvider) {
    return Positioned(
      bottom: 16,
      left: 16,
      right: 16,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // My location button
          FloatingActionButton(
            heroTag: "my_location",
            mini: true,
            backgroundColor: Colors.white,
            onPressed: _centerOnMyLocation,
            child: const Icon(Icons.my_location, color: AppTheme.primaryColor),
          ),
          
          // Location tracking toggle
          if (groupProvider.hasCurrentGroup)
            FloatingActionButton(
              heroTag: "location_tracking",
              mini: true,
              backgroundColor: _isTrackingLocation ? AppTheme.successColor : Colors.grey,
              onPressed: _isTrackingLocation ? _stopLocationTracking : _startLocationTracking,
              child: Icon(
                _isTrackingLocation ? Icons.stop : Icons.play_arrow,
                color: Colors.white,
              ),
            ),
          
          // Emergency button
          if (groupProvider.hasCurrentGroup)
            FloatingActionButton(
              heroTag: "emergency",
              mini: true,
              backgroundColor: AppTheme.emergencyColor,
              onPressed: () => _showEmergencyDialog(groupProvider, locationProvider, authProvider),
              child: const Icon(Icons.emergency, color: Colors.white),
            ),
          
          // Destination button
          if (groupProvider.hasCurrentGroup && groupProvider.isGroupLeader)
            FloatingActionButton(
              heroTag: "destination",
              mini: true,
              backgroundColor: AppTheme.primaryColor,
              onPressed: () => _showDestinationDialog(groupProvider, authProvider),
              child: const Icon(Icons.flag, color: Colors.white),
            ),
        ],
      ),
    );
  }

  void _updateMapWithLocations() async {
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    
    if (!groupProvider.hasCurrentGroup) {
      setState(() {
        _markers = {};
        _polylines = {};
      });
      return;
    }

    final group = groupProvider.currentGroup!;
    final currentUserId = authProvider.currentUserId ?? '';
    
    // Get member locations
    List<RiderLocation> memberLocations = group.members
        .where((member) => member.currentLocation != null)
        .map((member) => member.currentLocation!)
        .toList();

    // Create rider markers
    Set<Marker> riderMarkers = _mapService.createRiderMarkers(memberLocations, currentUserId);
    
    // Create stop markers
    Set<Marker> stopMarkers = _mapService.createStopMarkers(group.approvedStops);
    
    // Add destination marker
    Set<Marker> destinationMarkers = {};
    if (group.destination != null) {
      destinationMarkers.add(
        Marker(
          markerId: const MarkerId('destination'),
          position: LatLng(group.destination!.latitude, group.destination!.longitude),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          infoWindow: InfoWindow(
            title: 'Destination',
            snippet: group.destination!.address ?? 'Group destination',
          ),
        ),
      );
    }

    // Create route polylines if we have destination
    Set<Polyline> routePolylines = {};
    if (group.destination != null && memberLocations.isNotEmpty) {
      try {
        List<LatLng> routePoints = await _mapService.getDirections(
          LatLng(memberLocations.first.latitude, memberLocations.first.longitude),
          LatLng(group.destination!.latitude, group.destination!.longitude),
        );
        routePolylines = _mapService.createRoutePolylines(routePoints);
      } catch (e) {
        print('Failed to get route: $e');
      }
    }

    setState(() {
      _markers = {...riderMarkers, ...stopMarkers, ...destinationMarkers};
      _polylines = routePolylines;
    });
  }

  void _centerOnGroup() async {
    final groupProvider = Provider.of<GroupProvider>(context, listen: false);
    
    if (!groupProvider.hasCurrentGroup) return;
    
    List<LatLng> positions = groupProvider.currentGroup!.members
        .where((member) => member.currentLocation != null)
        .map((member) => LatLng(
          member.currentLocation!.latitude,
          member.currentLocation!.longitude,
        ))
        .toList();

    if (positions.isEmpty) return;

    CameraPosition cameraPosition = _mapService.calculateOptimalCameraPosition(positions);
    
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newCameraPosition(cameraPosition));
  }

  void _centerOnMyLocation() async {
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    
    if (locationProvider.currentLocation == null) return;
    
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newLatLng(
        LatLng(
          locationProvider.currentLocation!.latitude,
          locationProvider.currentLocation!.longitude,
        ),
      ),
    );
  }

  void _centerOnLocation(LatLng location) async {
    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(
      CameraUpdate.newLatLng(location),
    );
  }

  void _showEmergencyDialog(GroupProvider groupProvider, LocationProvider locationProvider, AuthProvider authProvider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Emergency Alert'),
        content: const Text('Select emergency type:'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ...EmergencyType.values.map((type) => TextButton(
            onPressed: () async {
              Navigator.pop(context);
              if (locationProvider.currentLocation != null && authProvider.currentUserId != null) {
                await groupProvider.sendEmergencyAlert(
                  authProvider.currentUserId!,
                  locationProvider.currentLocation!,
                  type,
                );
                
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Emergency alert sent: ${type.name}'),
                      backgroundColor: AppTheme.emergencyColor,
                    ),
                  );
                }
              }
            },
            child: Text(type.name.toUpperCase()),
          )),
        ],
      ),
    );
  }

  void _showDestinationDialog(GroupProvider groupProvider, AuthProvider authProvider) {
    final TextEditingController addressController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Set Destination'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: addressController,
              decoration: const InputDecoration(
                labelText: 'Destination Address',
                hintText: 'Enter address or place name',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              
              if (addressController.text.trim().isNotEmpty) {
                // Convert address to coordinates
                LatLng? coordinates = await _mapService.getCoordinatesFromAddress(
                  addressController.text.trim(),
                );
                
                if (coordinates != null && authProvider.currentUserId != null) {
                  RiderLocation destination = RiderLocation(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    latitude: coordinates.latitude,
                    longitude: coordinates.longitude,
                    timestamp: DateTime.now(),
                    type: LocationType.destination,
                    address: addressController.text.trim(),
                    description: 'Group destination',
                  );
                  
                  bool success = await groupProvider.updateDestination(
                    destination,
                    authProvider.currentUserId!,
                  );
                  
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(success 
                            ? 'Destination set successfully' 
                            : 'Failed to set destination'),
                        backgroundColor: success ? AppTheme.successColor : AppTheme.errorColor,
                      ),
                    );
                  }
                  
                  if (success) {
                    _updateMapWithLocations();
                  }
                } else {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Could not find location'),
                        backgroundColor: AppTheme.errorColor,
                      ),
                    );
                  }
                }
              }
            },
            child: const Text('Set'),
          ),
        ],
      ),
    );
  }
}