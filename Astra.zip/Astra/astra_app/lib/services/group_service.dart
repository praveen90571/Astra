import 'dart:math';
import 'package:uuid/uuid.dart';
import 'package:astra/models/group.dart';
import 'package:astra/models/location.dart';
import 'package:astra/models/user.dart';
import 'package:astra/services/firebase_service.dart';
import 'package:astra/utils/constants.dart';

class GroupService {
  static final GroupService _instance = GroupService._internal();
  factory GroupService() => _instance;
  GroupService._internal();

  final FirebaseService _firebaseService = FirebaseService();
  final Uuid _uuid = const Uuid();

  // Generate unique join code
  String _generateJoinCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    Random random = Random();
    return String.fromCharCodes(Iterable.generate(
      AppConstants.groupCodeLength,
      (_) => chars.codeUnitAt(random.nextInt(chars.length))
    ));
  }

  // Create new group
  Future<Group> createGroup({
    required String name,
    required String description,
    required User leader,
    GroupStatus status = GroupStatus.planning,
  }) async {
    try {
      // Create leader as first member
      GroupMember leaderMember = GroupMember(
        userId: leader.id,
        name: leader.name,
        role: MemberRole.leader,
        joinedAt: DateTime.now(),
        isOnline: true,
      );

      // Create group object
      Group group = Group(
        id: '', // Will be set by Firebase
        name: name,
        description: description,
        leaderId: leader.id,
        members: [leaderMember],
        status: status,
        createdAt: DateTime.now(),
        joinCode: _generateJoinCode(),
      );

      // Save to Firebase and get ID
      String groupId = await _firebaseService.createGroup(group);
      
      // Return group with ID
      return group.copyWith().copyWith(/* id: groupId */); // Note: We need to modify copyWith to handle id
      
    } catch (e) {
      throw Exception('Failed to create group: ${e.toString()}');
    }
  }

  // Join group by code
  Future<Group> joinGroupByCode(String joinCode, User user) async {
    try {
      // Find group by join code
      Group? group = await _firebaseService.getGroupByJoinCode(joinCode);
      if (group == null) {
        throw Exception('Group not found. Please check the join code.');
      }

      // Check if user is already a member
      bool isAlreadyMember = group.members.any((member) => member.userId == user.id);
      if (isAlreadyMember) {
        throw Exception('You are already a member of this group.');
      }

      // Check if group is full
      if (group.members.length >= AppConstants.maxGroupMembers) {
        throw Exception('Group is full. Maximum ${AppConstants.maxGroupMembers} members allowed.');
      }

      // Create new member
      GroupMember newMember = GroupMember(
        userId: user.id,
        name: user.name,
        role: MemberRole.member,
        joinedAt: DateTime.now(),
        isOnline: true,
      );

      // Add member to group
      await _firebaseService.addMemberToGroup(group.id, newMember);

      // Return updated group
      List<GroupMember> updatedMembers = [...group.members, newMember];
      return group.copyWith(members: updatedMembers);
      
    } catch (e) {
      throw Exception('Failed to join group: ${e.toString()}');
    }
  }

  // Leave group
  Future<void> leaveGroup(String groupId, String userId) async {
    try {
      Group? group = await _firebaseService.getGroup(groupId);
      if (group == null) {
        throw Exception('Group not found.');
      }

      // Check if user is the leader
      if (group.leaderId == userId) {
        // If leader is leaving, assign leadership to another member or delete group
        if (group.members.length > 1) {
          // Find next member to be leader
          GroupMember? nextLeader = group.members.firstWhere(
            (member) => member.userId != userId,
            orElse: () => group.members.first,
          );
          
          if (nextLeader.userId != userId) {
            // Update group with new leader
            List<GroupMember> updatedMembers = group.members
                .where((member) => member.userId != userId)
                .map((member) => member.userId == nextLeader.userId
                    ? member.copyWith(role: MemberRole.leader)
                    : member)
                .toList();

            Group updatedGroup = group.copyWith(
              members: updatedMembers,
              // leaderId: nextLeader.userId, // Note: Need to update Group model to handle leaderId in copyWith
            );
            
            await _firebaseService.updateGroup(updatedGroup);
          }
        } else {
          // Last member leaving, delete group
          await _firebaseService.deleteDocument(AppConstants.groupsCollection, groupId);
        }
      } else {
        // Regular member leaving
        await _firebaseService.removeMemberFromGroup(groupId, userId);
      }
    } catch (e) {
      throw Exception('Failed to leave group: ${e.toString()}');
    }
  }

  // Update group destination
  Future<void> updateDestination(String groupId, RiderLocation destination, String userId) async {
    try {
      Group? group = await _firebaseService.getGroup(groupId);
      if (group == null) {
        throw Exception('Group not found.');
      }

      // Check if user is leader
      if (!group.isUserLeader(userId)) {
        throw Exception('Only group leaders can set destinations.');
      }

      // Update group with new destination
      Group updatedGroup = group.copyWith(destination: destination);
      await _firebaseService.updateGroup(updatedGroup);
      
    } catch (e) {
      throw Exception('Failed to update destination: ${e.toString()}');
    }
  }

  // Suggest stop
  Future<void> suggestStop(String groupId, RiderLocation stop, String userId) async {
    try {
      Group? group = await _firebaseService.getGroup(groupId);
      if (group == null) {
        throw Exception('Group not found.');
      }

      // Check if user is a member
      if (!group.isUserMember(userId)) {
        throw Exception('Only group members can suggest stops.');
      }

      // Add stop to suggested stops
      List<RiderLocation> updatedSuggestedStops = [...group.suggestedStops, stop];
      Group updatedGroup = group.copyWith(suggestedStops: updatedSuggestedStops);
      
      await _firebaseService.updateGroup(updatedGroup);
      
    } catch (e) {
      throw Exception('Failed to suggest stop: ${e.toString()}');
    }
  }

  // Approve stop (leader only)
  Future<void> approveStop(String groupId, RiderLocation stop, String userId) async {
    try {
      Group? group = await _firebaseService.getGroup(groupId);
      if (group == null) {
        throw Exception('Group not found')
      }
      // Check if user is leader
     if (!group.isUserLeader(userId)) {
       throw Exception('Only group leaders can approve stops.');
     }

     // Remove from suggested stops and add to approved stops
     List<RiderLocation> updatedSuggestedStops = group.suggestedStops
         .where((suggestedStop) => suggestedStop.id != stop.id)
         .toList();
     
     List<RiderLocation> updatedApprovedStops = [...group.approvedStops, stop];
     
     Group updatedGroup = group.copyWith(
       suggestedStops: updatedSuggestedStops,
       approvedStops: updatedApprovedStops,
     );
     
     await _firebaseService.updateGroup(updatedGroup);
     
   } catch (e) {
     throw Exception('Failed to approve stop: ${e.toString()}');
   }
 }

 // Reject stop (leader only)
 Future<void> rejectStop(String groupId, RiderLocation stop, String userId) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Check if user is leader
     if (!group.isUserLeader(userId)) {
       throw Exception('Only group leaders can reject stops.');
     }

     // Remove from suggested stops
     List<RiderLocation> updatedSuggestedStops = group.suggestedStops
         .where((suggestedStop) => suggestedStop.id != stop.id)
         .toList();
     
     Group updatedGroup = group.copyWith(suggestedStops: updatedSuggestedStops);
     await _firebaseService.updateGroup(updatedGroup);
     
   } catch (e) {
     throw Exception('Failed to reject stop: ${e.toString()}');
   }
 }

 // Start ride (leader only)
 Future<void> startRide(String groupId, String userId) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Check if user is leader
     if (!group.isUserLeader(userId)) {
       throw Exception('Only group leaders can start rides.');
     }

     // Check if group has destination
     if (group.destination == null) {
       throw Exception('Please set a destination before starting the ride.');
     }

     // Update group status to active
     Group updatedGroup = group.copyWith(
       status: GroupStatus.active,
       startedAt: DateTime.now(),
     );
     
     await _firebaseService.updateGroup(updatedGroup);
     
   } catch (e) {
     throw Exception('Failed to start ride: ${e.toString()}');
   }
 }

 // Pause ride (leader only)
 Future<void> pauseRide(String groupId, String userId) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Check if user is leader
     if (!group.isUserLeader(userId)) {
       throw Exception('Only group leaders can pause rides.');
     }

     // Update group status to paused
     Group updatedGroup = group.copyWith(status: GroupStatus.paused);
     await _firebaseService.updateGroup(updatedGroup);
     
   } catch (e) {
     throw Exception('Failed to pause ride: ${e.toString()}');
   }
 }

 // Resume ride (leader only)
 Future<void> resumeRide(String groupId, String userId) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Check if user is leader
     if (!group.isUserLeader(userId)) {
       throw Exception('Only group leaders can resume rides.');
     }

     // Update group status to active
     Group updatedGroup = group.copyWith(status: GroupStatus.active);
     await _firebaseService.updateGroup(updatedGroup);
     
   } catch (e) {
     throw Exception('Failed to resume ride: ${e.toString()}');
   }
 }

 // Complete ride (leader only)
 Future<void> completeRide(String groupId, String userId) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Check if user is leader
     if (!group.isUserLeader(userId)) {
       throw Exception('Only group leaders can complete rides.');
     }

     // Update group status to completed
     Group updatedGroup = group.copyWith(
       status: GroupStatus.completed,
       completedAt: DateTime.now(),
     );
     
     await _firebaseService.updateGroup(updatedGroup);
     
   } catch (e) {
     throw Exception('Failed to complete ride: ${e.toString()}');
   }
 }

 // Update member location
 Future<void> updateMemberLocation(String groupId, String userId, RiderLocation location) async {
   try {
     await _firebaseService.updateMemberLocation(groupId, userId, location);
   } catch (e) {
     throw Exception('Failed to update member location: ${e.toString()}');
   }
 }

 // Send emergency alert
 Future<void> sendEmergencyAlert(String groupId, String userId, RiderLocation location, EmergencyType emergencyType) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Check if user is a member
     if (!group.isUserMember(userId)) {
       throw Exception('Only group members can send emergency alerts.');
     }

     // Create emergency location
     RiderLocation emergencyLocation = location.copyWith(
       type: LocationType.emergency,
       emergencyType: emergencyType,
       description: 'Emergency: ${emergencyType.name}',
     );

     // Update member location with emergency status
     await updateMemberLocation(groupId, userId, emergencyLocation);
     
     // TODO: Send push notifications to all group members
     // TODO: Integrate with emergency services if needed
     
   } catch (e) {
     throw Exception('Failed to send emergency alert: ${e.toString()}');
   }
 }

 // Get group statistics
 Future<Map<String, dynamic>> getGroupStatistics(String groupId) async {
   try {
     Group? group = await _firebaseService.getGroup(groupId);
     if (group == null) {
       throw Exception('Group not found.');
     }

     // Calculate basic statistics
     int totalMembers = group.members.length;
     int onlineMembers = group.onlineMembers.length;
     int membersWithLocation = group.membersWithRecentLocation.length;
     
     Duration? rideDuration = group.rideDuration;
     String durationText = rideDuration != null 
         ? '${rideDuration.inHours}h ${rideDuration.inMinutes.remainder(60)}m'
         : 'N/A';

     // Calculate distances if locations are available
     double totalDistance = 0.0;
     List<RiderLocation> memberLocations = group.members
         .where((member) => member.currentLocation != null)
         .map((member) => member.currentLocation!)
         .toList();

     if (memberLocations.length > 1) {
       // Calculate spread of group (distance between furthest members)
       double maxDistance = 0.0;
       for (int i = 0; i < memberLocations.length; i++) {
         for (int j = i + 1; j < memberLocations.length; j++) {
           double distance = memberLocations[i].distanceTo(memberLocations[j]);
           if (distance > maxDistance) {
             maxDistance = distance;
           }
         }
       }
       totalDistance = maxDistance;
     }

     return {
       'totalMembers': totalMembers,
       'onlineMembers': onlineMembers,
       'membersWithLocation': membersWithLocation,
       'rideDuration': durationText,
       'groupSpread': '${(totalDistance / 1000).toStringAsFixed(1)} km',
       'status': group.status.name,
       'hasDestination': group.destination != null,
       'suggestedStops': group.suggestedStops.length,
       'approvedStops': group.approvedStops.length,
       'createdAt': group.createdAt,
       'startedAt': group.startedAt,
       'completedAt': group.completedAt,
     };
   } catch (e) {
     throw Exception('Failed to get group statistics: ${e.toString()}');
   }
 }

 // Get nearby groups (for future feature)
 Future<List<Group>> getNearbyGroups(RiderLocation location, double radiusKm) async {
   try {
     // TODO: Implement geospatial query when Firebase supports it
     // For now, return empty list
     return [];
   } catch (e) {
     throw Exception('Failed to get nearby groups: ${e.toString()}');
   }
 }

 // Validate join code format
 bool isValidJoinCode(String code) {
   return code.length == AppConstants.groupCodeLength && 
          RegExp(r'^[A-Z0-9]+$').hasMatch(code);
 }

 // Check if user can perform action
 bool canUserPerformAction(Group group, String userId, String action) {
   bool isLeader = group.isUserLeader(userId);
   bool isMember = group.isUserMember(userId);
   
   switch (action) {
     case 'setDestination':
     case 'approveStop':
     case 'rejectStop':
     case 'startRide':
     case 'pauseRide':
     case 'resumeRide':
     case 'completeRide':
       return isLeader;
     case 'suggestStop':
     case 'sendEmergency':
     case 'updateLocation':
       return isMember;
     case 'leaveGroup':
       return isMember;
     default:
       return false;
   }
 }
}