import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:astra/models/location.dart';
import 'package:astra/utils/constants.dart';

class LocationService {
  static final LocationService _instance = LocationService._internal();
  factory LocationService() => _instance;
  LocationService._internal();

  StreamSubscription<Position>? _positionStream;
  StreamController<RiderLocation>? _locationController;
  RiderLocation? _lastKnownLocation;
  bool _isTracking = false;

  // Get location stream
  Stream<RiderLocation> get locationStream {
    _locationController ??= StreamController<RiderLocation>.broadcast();
    return _locationController!.stream;
  }

  // Get last known location
  RiderLocation? get lastKnownLocation => _lastKnownLocation;

  // Check if currently tracking
  bool get isTracking => _isTracking;

  // Request location permissions
  Future<bool> requestLocationPermission() async {
    try {
      // Check if location services are enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        throw Exception('Location services are disabled. Please enable them in settings.');
      }

      // Check current permission status
      LocationPermission permission = await Geolocator.checkPermission();
      
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Location permissions are denied');
        }
      }
      
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Location permissions are permanently denied. Please enable them in settings.');
      }

      // Request background location permission for continuous tracking
      if (permission == LocationPermission.whileInUse) {
        await Permission.locationAlways.request();
      }

      return true;
    } catch (e) {
      throw Exception('Failed to get location permission: ${e.toString()}');
    }
  }

  // Get current location once
  Future<RiderLocation> getCurrentLocation() async {
    try {
      bool hasPermission = await requestLocationPermission();
      if (!hasPermission) {
        throw Exception('Location permission denied');
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: Duration(seconds: AppConstants.locationTimeoutSeconds),
      );

      RiderLocation location = RiderLocation(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        latitude: position.latitude,
        longitude: position.longitude,
        altitude: position.altitude,
        accuracy: position.accuracy,
        speed: position.speed,
        heading: position.heading,
        timestamp: DateTime.now(),
        type: LocationType.rider,
      );

      _lastKnownLocation = location;
      return location;
    } catch (e) {
      throw Exception('Failed to get current location: ${e.toString()}');
    }
  }

  // Start continuous location tracking
  Future<void> startLocationTracking({String? userId}) async {
    try {
      if (_isTracking) return;

      bool hasPermission = await requestLocationPermission();
      if (!hasPermission) {
        throw Exception('Location permission denied');
      }

      _locationController ??= StreamController<RiderLocation>.broadcast();

      const LocationSettings locationSettings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: AppConstants.minDistanceFilter.toInt(),
      );

      _positionStream = Geolocator.getPositionStream(
        locationSettings: locationSettings,
      ).listen(
        (Position position) {
          RiderLocation location = RiderLocation(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            latitude: position.latitude,
            longitude: position.longitude,
            altitude: position.altitude,
            accuracy: position.accuracy,
            speed: position.speed,
            heading: position.heading,
            timestamp: DateTime.now(),
            type: LocationType.rider,
            userId: userId,
          );

          _lastKnownLocation = location;
          _locationController?.add(location);
        },
        onError: (error) {
          print('Location tracking error: $error');
          _locationController?.addError(error);
        },
      );

      _isTracking = true;
    } catch (e) {
      throw Exception('Failed to start location tracking: ${e.toString()}');
    }
  }

  // Stop location tracking
  Future<void> stopLocationTracking() async {
    try {
      await _positionStream?.cancel();
      _positionStream = null;
      _isTracking = false;
    } catch (e) {
      print('Failed to stop location tracking: ${e.toString()}');
    }
  }

  // Calculate distance between two locations
  double calculateDistance(RiderLocation from, RiderLocation to) {
    return Geolocator.distanceBetween(
      from.latitude,
      from.longitude,
      to.latitude,
      to.longitude,
    );
  }

  // Calculate bearing between two locations
  double calculateBearing(RiderLocation from, RiderLocation to) {
    return Geolocator.bearingBetween(
      from.latitude,
      from.longitude,
      to.latitude,
      to.longitude,
    );
  }

  // Check if location is within a certain radius of another location
  bool isLocationNearby(RiderLocation location1, RiderLocation location2, double radiusInMeters) {
    double distance = calculateDistance(location1, location2);
    return distance <= radiusInMeters;
  }

  // Get location accuracy status
  String getLocationAccuracyStatus(double? accuracy) {
    if (accuracy == null) return 'Unknown';
    if (accuracy < 5) return 'Excellent';
    if (accuracy < 10) return 'Good';
    if (accuracy < 20) return 'Fair';
    return 'Poor';
  }

  // Check if location services are available
  Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  // Open location settings
  Future<void> openLocationSettings() async {
    await Geolocator.openLocationSettings();
  }

  // Dispose resources
  void dispose() {
    stopLocationTracking();
    _locationController?.close();
    _locationController = null;
  }
}