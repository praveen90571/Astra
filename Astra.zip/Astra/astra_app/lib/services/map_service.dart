import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:astra/models/location.dart';
import 'package:astra/config/app_config.dart';
import 'package:astra/config/theme.dart';

class MapService {
  static final MapService _instance = MapService._internal();
  factory MapService() => _instance;
  MapService._internal();

  // Google Maps API endpoints
  static const String _geocodingBaseUrl = 'https://maps.googleapis.com/maps/api/geocode/json';
  static const String _directionsBaseUrl = 'https://maps.googleapis.com/maps/api/directions/json';
  static const String _placesBaseUrl = 'https://maps.googleapis.com/maps/api/place';

  // Create markers for riders
  Set<Marker> createRiderMarkers(List<RiderLocation> locations, String currentUserId) {
    Set<Marker> markers = {};
    
    for (RiderLocation location in locations) {
      String markerId = location.userId ?? location.id;
      bool isCurrentUser = location.userId == currentUserId;
      bool isLeader = location.type == LocationType.rider && location.userId != null;
      bool isEmergency = location.type == LocationType.emergency;
      
      // Choose marker color based on status
      BitmapDescriptor markerIcon;
      if (isEmergency) {
        markerIcon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed);
      } else if (isCurrentUser) {
        markerIcon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue);
      } else if (isLeader) {
        markerIcon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueOrange);
      } else {
        markerIcon = BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen);
      }

      markers.add(
        Marker(
          markerId: MarkerId(markerId),
          position: LatLng(location.latitude, location.longitude),
          icon: markerIcon,
          infoWindow: InfoWindow(
            title: isCurrentUser ? 'You' : 'Rider',
            snippet: _getMarkerSnippet(location),
          ),
          rotation: location.heading ?? 0.0,
        ),
      );
    }
    
    return markers;
  }

  // Create markers for stops
  Set<Marker> createStopMarkers(List<RiderLocation> stops) {
    Set<Marker> markers = {};
    
    for (int i = 0; i < stops.length; i++) {
      RiderLocation stop = stops[i];
      
      markers.add(
        Marker(
          markerId: MarkerId('stop_${stop.id}'),
          position: LatLng(stop.latitude, stop.longitude),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueYellow),
          infoWindow: InfoWindow(
            title: 'Stop ${i + 1}',
            snippet: stop.description ?? stop.address ?? 'Planned stop',
          ),
        ),
      );
    }
    
    return markers;
  }

  // Create polyline for route
  Set<Polyline> createRoutePolylines(List<LatLng> routePoints) {
    if (routePoints.isEmpty) return {};
    
    return {
      Polyline(
        polylineId: const PolylineId('route'),
        points: routePoints,
        color: AppTheme.routeColor,
        width: 4,
        patterns: [],
      ),
    };
  }

  // Get directions between two points
  Future<List<LatLng>> getDirections(LatLng origin, LatLng destination) async {
    try {
      String url = '$_directionsBaseUrl?'
          'origin=${origin.latitude},${origin.longitude}&'
          'destination=${destination.latitude},${destination.longitude}&'
          'mode=driving&'
          'key=${AppConfig.googleMapsApiKey}';

      http.Response response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        
        if (data['status'] == 'OK' && data['routes'].isNotEmpty) {
          String encodedPolyline = data['routes'][0]['overview_polyline']['points'];
          return _decodePolyline(encodedPolyline);
        } else {
          throw Exception('No route found: ${data['status']}');
        }
      } else {
        throw Exception('Failed to get directions: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to get directions: ${e.toString()}');
    }
  }

  // Get directions with waypoints
  Future<List<LatLng>> getDirectionsWithWaypoints(
    LatLng origin,
    LatLng destination,
    List<LatLng> waypoints,
  ) async {
    try {
      String waypointsParam = waypoints
          .map((point) => '${point.latitude},${point.longitude}')
          .join('|');

      String url = '$_directionsBaseUrl?'
          'origin=${origin.latitude},${origin.longitude}&'
          'destination=${destination.latitude},${destination.longitude}&'
          'waypoints=$waypointsParam&'
          'mode=driving&'
          'key=${AppConfig.googleMapsApiKey}';

      http.Response response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        
        if (data['status'] == 'OK' && data['routes'].isNotEmpty) {
          String encodedPolyline = data['routes'][0]['overview_polyline']['points'];
          return _decodePolyline(encodedPolyline);
        } else {
          throw Exception('No route found: ${data['status']}');
        }
      } else {
        throw Exception('Failed to get directions: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Failed to get directions with waypoints: ${e.toString()}');
    }
  }

  // Get address from coordinates (reverse geocoding)
  Future<String?> getAddressFromCoordinates(double latitude, double longitude) async {
    try {
      String url = '$_geocodingBaseUrl?'
          'latlng=$latitude,$longitude&'
          'key=${AppConfig.googleMapsApiKey}';

      http.Response response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        
        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          return data['results'][0]['formatted_address'];
        }
      }
      return null;
    } catch (e) {
      print('Failed to get address: ${e.toString()}');
      return null;
    }
  }

  // Get coordinates from address (geocoding)
  Future<LatLng?> getCoordinatesFromAddress(String address) async {
    try {
      String url = '$_geocodingBaseUrl?'
          'address=${Uri.encodeComponent(address)}&'
          'key=${AppConfig.googleMapsApiKey}';

      http.Response response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        Map<String, dynamic> data = json.decode(response.body);
        
        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          Map<String, dynamic> location = data['results'][0]['geometry']['location'];
          return LatLng(location['lat'], location['lng']);
        }
      }
      return null;
    } catch (e) {
      print('Failed to get coordinates: ${e.toString()}');
      return null;
    }
  }

  // Calculate optimal camera position for multiple markers
  CameraPosition calculateOptimalCameraPosition(List<LatLng> positions) {
    if (positions.isEmpty) {
      return const CameraPosition(
        target: LatLng(0, 0),
        zoom: 10,
      );
    }

    if (positions.length == 1) {
      return CameraPosition(
        target: positions.first,
        zoom: 15,
      );
    }

    // Calculate bounds
    double minLat = positions.first.latitude;
    double maxLat = positions.first.latitude;
    double minLng = positions.first.longitude;
    double maxLng = positions.first.longitude;

    for (LatLng position in positions) {
      minLat = minLat < position.latitude ? minLat : position.latitude;
      maxLat = maxLat > position.latitude ? maxLat : position.latitude;
      minLng = minLng < position.longitude ? minLng : position.longitude;
      maxLng = maxLng > position.longitude ? maxLng : position.longitude;
    }

    // Calculate center
    double centerLat = (minLat + maxLat) / 2;
    double centerLng = (minLng + maxLng) / 2;

    // Calculate zoom level based on bounds
    double latDiff = maxLat - minLat;
    double lngDiff = maxLng - minLng;
    double maxDiff = latDiff > lngDiff ? latDiff : lngDiff;
    
    double zoom = 15.0;
    if (maxDiff > 0.01) zoom = 12.0;
    if (maxDiff > 0.05) zoom = 10.0;
    if (maxDiff > 0.1) zoom = 8.0;
    if (maxDiff > 0.5) zoom = 6.0;

    return CameraPosition(
      target: LatLng(centerLat, centerLng),
      zoom: zoom,
    );
  }

  // Helper method to get marker snippet
  String _getMarkerSnippet(RiderLocation location) {
    List<String> snippetParts = [];
    
    if (location.speed != null) {
      snippetParts.add(location.speedKmh);
    }
    
    if (location.isEmergency) {
      snippetParts.add('EMERGENCY: ${location.emergencyType?.name ?? 'Unknown'}');
    }
    
    if (location.address != null) {
      snippetParts.add(location.address!);
    }
    
    return snippetParts.join(' • ');
  }

  // Decode polyline from Google Directions API
  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> polylineCoordinates = [];
    int index = 0;
    int len = encoded.length;
    int lat = 0;
    int lng = 0;

    while (index < len) {
      int b;
      int shift = 0;
      int result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
      lng += dlng;

      polylineCoordinates.add(LatLng(lat / 1E5, lng / 1E5));
    }

    return polylineCoordinates;
  }
}