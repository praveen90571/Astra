class AppConstants {
  // App Info
  static const String appName = 'Astra';
  static const String appVersion = '1.0.0';
  
  // Firebase Collections
  static const String usersCollection = 'users';
  static const String groupsCollection = 'groups';
  static const String ridesCollection = 'rides';
  
  // Location Settings
  static const double locationUpdateInterval = 5.0; // seconds
  static const double minDistanceFilter = 10.0; // meters
  static const int locationTimeoutSeconds = 30;
  
  // Group Settings
  static const int maxGroupMembers = 10;
  static const int groupCodeLength = 6;
  
  // Map Settings
  static const double defaultZoom = 15.0;
  static const double riderMarkerSize = 40.0;
  static const double stopMarkerSize = 35.0;
  
  // Emergency Settings
  static const int emergencyTimeoutSeconds = 300; // 5 minutes
  
  // Socket Events
  static const String socketConnect = 'connect';
  static const String socketDisconnect = 'disconnect';
  static const String socketJoinGroup = 'join_group';
  static const String socketLeaveGroup = 'leave_group';
  static const String socketLocationUpdate = 'location_update';
  static const String socketEmergencyAlert = 'emergency_alert';
  static const String socketDestinationUpdate = 'destination_update';
  static const String socketStopSuggestion = 'stop_suggestion';
}

class AppStrings {
  // Authentication
  static const String loginTitle = 'Welcome to Astra';
  static const String loginSubtitle = 'Connect with your riding group';
  static const String registerTitle = 'Join Astra';
  static const String registerSubtitle = 'Start your group riding adventure';
  
  // Errors
  static const String networkError = 'Please check your internet connection';
  static const String locationError = 'Location access is required for group rides';
  static const String permissionError = 'Please grant required permissions';
  static const String genericError = 'Something went wrong. Please try again.';
  
  // Success Messages
  static const String groupCreated = 'Group created successfully!';
  static const String groupJoined = 'Joined group successfully!';
  static const String locationShared = 'Location shared with group';
}